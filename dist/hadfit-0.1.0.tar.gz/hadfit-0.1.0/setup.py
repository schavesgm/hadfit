# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hadfit', 'hadfit.analysis', 'hadfit.hadron', 'hadfit.model', 'hadfit.msfit']

package_data = \
{'': ['*']}

install_requires = \
['lmfit>=1.0.2,<2.0.0',
 'matplotlib>=3.4.3,<4.0.0',
 'numpy>=1.21.2,<2.0.0',
 'scipy>=1.7.1,<2.0.0',
 'sympy>=1.8,<2.0']

setup_kwargs = {
    'name': 'hadfit',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Sergio Chaves Garcia-Mascaraque',
    'author_email': 'sergiozteskate@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
